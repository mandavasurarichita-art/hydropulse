
import { useEffect, useState } from "react";
import Auth from "./Auth.jsx";
import UsageRecords from "./UsageRecords.jsx";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from "recharts";
import {
  Droplets, Waves, Thermometer, Activity,
  LayoutDashboard, ChartNoAxesCombined, ClipboardList,
  Bell, Settings, Wifi, Menu
} from "lucide-react";
import "./App.css";

const API = "http://localhost:5000";

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [section, setSection] = useState("Overview");
  const [sensor, setSensor] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  const menu = [
    { name: "Overview", icon: LayoutDashboard },
    { name: "Water Levels", icon: Waves },
    { name: "Analytics", icon: ChartNoAxesCombined },
    { name: "Usage Records", icon: ClipboardList },
    { name: "Alerts", icon: Bell },
    { name: "Settings", icon: Settings }
  ];

  useEffect(() => {
    if (!loggedIn) return;

    let active = true;

    async function loadData() {
      try {
        const [sensorResponse, historyResponse] = await Promise.all([
          fetch(`${API}/api/sensors`),
          fetch(`${API}/api/sensors/history`)
        ]);

        if (!sensorResponse.ok || !historyResponse.ok) {
          throw new Error("API unavailable");
        }

        const sensorData = await sensorResponse.json();
        const historyData = await historyResponse.json();

        if (active) {
          setSensor(sensorData);
          setHistory(Array.isArray(historyData) ? historyData : []);
          setError(false);
        }
      } catch {
        if (active) setError(true);
      }
    }

    loadData();
    const timer = setInterval(loadData, 5000);

    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [loggedIn]);

  const level = Number(sensor?.waterLevel ?? 0);
  const temperature = Number(sensor?.temperature ?? 0);
  const flow = Number(sensor?.flowRate ?? 0);
  const quality = Number(sensor?.quality ?? 0);

  const alerts = [];

  if (error) alerts.push("Cannot connect to the backend. Check that the server is running.");
  if (sensor && level < 25) alerts.push("Warning: Water level is low.");
  if (sensor && temperature > 35) alerts.push("Warning: Water temperature is high.");
  if (sensor && quality < 50) alerts.push("Warning: Water quality needs attention.");

  function changeSection(name) {
    setSection(name);
    setMobileMenu(false);
  }

  function metricCard(title, value, unit, Icon, color) {
    return (
      <div className="metric" key={title}>
        <div className={`metric-icon ${color}`}>
          <Icon size={23} />
        </div>
        <p>{title}</p>
        <h2>{value}{unit}</h2>
        <span>{error ? "Connection unavailable" : "Simulated reading"}</span>
      </div>
    );
  }

  function chart(title, dataKey, color, unit) {
    return (
      <section className="panel" key={title}>
        <div className="panel-heading">
          <h3>{title}</h3>
          <span>Recent readings</span>
        </div>
        <div className="chart">
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={history}>
              <CartesianGrid strokeDasharray="3 3" stroke="#24364b" />
              <XAxis dataKey="time" stroke="#8da4b9" />
              <YAxis stroke="#8da4b9" />
              <Tooltip
                contentStyle={{
                  background: "#102338",
                  border: "1px solid #29445d",
                  borderRadius: "8px"
                }}
              />
              <Line
                type="monotone"
                dataKey={dataKey}
                stroke={color}
                strokeWidth={3}
                dot={false}
                connectNulls
                name={title}
                unit={unit}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
    );
  }

  function tank() {
    const safeLevel = Math.max(0, Math.min(100, level));

    return (
      <section className="panel tank-section">
        <div className="panel-heading">
          <h3>Water Tank</h3>
          <span>{error ? "Offline" : "Monitoring"}</span>
        </div>
        <div className="tank-visual">
          <div className="water-tank">
            <div
              className="tank-water"
              style={{ height: `${safeLevel}%` }}
            />
            <div className="tank-percentage">
              {sensor ? `${safeLevel}%` : "--"}
            </div>
          </div>
          <h3>{sensor ? `${safeLevel}% Full` : "Waiting for data"}</h3>
          <p>
            {safeLevel < 25 ? "Low water level" : "Water level status"}
          </p>
        </div>
        <div className="tank-progress">
          <div
            className="tank-progress-fill"
            style={{ width: `${safeLevel}%` }}
          />
        </div>
        <div className="tank-labels">
          <span>0%</span>
          <span>100%</span>
        </div>
      </section>
    );
  }

  function overview() {
    return (
      <>
        <div className="cards">
          {metricCard("Water Level", sensor ? level : "--", sensor ? "%" : "", Droplets, "blue")}
          {metricCard("Flow Rate", sensor ? flow : "--", sensor ? " L/m" : "", Waves, "cyan")}
          {metricCard("Temperature", sensor ? temperature : "--", sensor ? "°C" : "", Thermometer, "orange")}
          {metricCard("Water Quality", sensor ? quality : "--", sensor ? "/100" : "", Activity, "green")}
        </div>

        <div className="content-grid">
          {tank()}
          {chart("Water Level History", "waterLevel", "#38bdf8", "%")}
        </div>

        <section className="panel">
          <div className="panel-heading">
            <h3>System Status</h3>
          </div>
          <div className="status-row">
            <span>Backend Connection</span>
            <strong className={error ? "bad" : "good"}>
              {error ? "Offline" : "Connected"}
            </strong>
          </div>
          <div className="status-row">
            <span>Sensor Data</span>
            <strong className={sensor && !error ? "good" : "bad"}>
              {sensor && !error ? "Available" : "Unavailable"}
            </strong>
          </div>
        </section>
      </>
    );
  }

  function waterLevels() {
    return (
      <>
        <div className="cards">
          {metricCard("Current Water Level", sensor ? level : "--", sensor ? "%" : "", Droplets, "blue")}
          {metricCard("Current Flow", sensor ? flow : "--", sensor ? " L/m" : "", Waves, "cyan")}
        </div>
        <div className="content-grid">
          {tank()}
          {chart("Water Level History", "waterLevel", "#38bdf8", "%")}
        </div>
      </>
    );
  }

  function analytics() {
    return (
      <div className="content-grid">
        {chart("Water Level Trend", "waterLevel", "#38bdf8", "%")}
        {chart("Flow Rate Trend", "flowRate", "#2dd4bf", " L/m")}
        {chart("Temperature Trend", "temperature", "#fb923c", "°C")}
        {chart("Water Quality Trend", "quality", "#4ade80", "/100")}
      </div>
    );
  }

  function alertsPage() {
    return (
      <section className="panel">
        <div className="panel-heading">
          <h3>Alert Feed</h3>
          <span>{alerts.length} active</span>
        </div>
        {alerts.length === 0 ? (
          <p className="no-alert">No active alerts. The system is running normally.</p>
        ) : (
          alerts.map((message, index) => (
            <div className="alert" key={index}>
              <Bell size={20} />
              <span>{message}</span>
            </div>
          ))
        )}
      </section>
    );
  }

  function settingsPage() {
    return (
      <section className="panel">
        <div className="panel-heading">
          <h3>System Settings</h3>
        </div>
        <div className="status-row">
          <span>Project</span>
          <strong>HydroPulse</strong>
        </div>
        <div className="status-row">
          <span>Backend API</span>
          <strong>localhost:5000</strong>
        </div>
        <div className="status-row">
          <span>Refresh Interval</span>
          <strong>5 seconds</strong>
        </div>
        <div className="status-row">
          <span>Data Source</span>
          <strong>Simulated sensor data</strong>
        </div>
        <p className="note">
          This project currently uses simulated readings, not a physical water sensor.
        </p>
      </section>
    );
  }

  function renderSection() {
    switch (section) {
      case "Overview":
        return overview();
      case "Water Levels":
        return waterLevels();
      case "Analytics":
        return analytics();
      case "Usage Records":
        return <UsageRecords />;
      case "Alerts":
        return alertsPage();
      case "Settings":
        return settingsPage();
      default:
        return overview();
    }
  }

  if (!loggedIn) {
    return <Auth onLogin={() => setLoggedIn(true)} />;
  }

  return (
    <div className="dashboard-layout">
      {mobileMenu && (
        <button
          className="sidebar-backdrop"
          aria-label="Close navigation"
          onClick={() => setMobileMenu(false)}
        />
      )}

      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="sidebar-brand">
          <Droplets size={30} />
          <div>
            <h2>HydroPulse</h2>
            <span>Water Monitoring</span>
          </div>
        </div>

        <p className="menu-label">MAIN MENU</p>

        <nav className="sidebar-menu">
          {menu.map(({ name, icon: Icon }) => (
            <button
              key={name}
              className={`nav-item ${section === name ? "nav-active" : ""}`}
              onClick={() => changeSection(name)}
            >
              <Icon size={20} />
              <span>{name}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <span className={`connection-dot ${error ? "dot-offline" : ""}`} />
          <span>{error ? "Backend Offline" : "System Connected"}</span>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button
            className="mobile-menu-button"
            onClick={() => setMobileMenu(!mobileMenu)}
            aria-label="Toggle menu"
          >
            <Menu size={23} />
          </button>
          <div>
            <h1>{section}</h1>
            <p>Monitor and manage your water system</p>
          </div>
          <div className={`connection ${error ? "connection-offline" : ""}`}>
            <Wifi size={18} />
            <span>{error ? "Offline" : "Connected"}</span>
          </div>
        </header>

        <div className="page-content">
          {renderSection()}
        </div>

        <footer className="dashboard-footer">
          HydroPulse · Water Monitoring Dashboard
        </footer>
      </main>
    </div>
  );
}

export default App;
