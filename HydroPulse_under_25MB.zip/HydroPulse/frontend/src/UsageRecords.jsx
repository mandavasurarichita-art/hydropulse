
import { useEffect, useState } from "react";

const API = "http://localhost:5000/api/records";

function UsageRecords() {
  const [records, setRecords] = useState([]);
  const [date, setDate] = useState("");
  const [category, setCategory] = useState("Home");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");

  async function loadRecords() {
    try {
      const response = await fetch(API);

      if (!response.ok) {
        throw new Error("Could not load records.");
      }

      const data = await response.json();
      setRecords(data);
      setError("");
    } catch {
      setError("Cannot connect to backend. Check the server.");
    }
  }

  useEffect(() => {
    loadRecords();
  }, []);

  async function addRecord(e) {
    e.preventDefault();

    const newRecord = {
      date,
      category,
      amount: Number(amount)
    };

    try {
      const response = await fetch(API, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(newRecord)
      });

      if (!response.ok) {
        throw new Error("Could not add record.");
      }

      const savedRecord = await response.json();

      setRecords((oldRecords) => [
        ...oldRecords,
        savedRecord
      ]);

      setDate("");
      setAmount("");
      setError("");
    } catch {
      setError("Record could not be saved. Check the backend.");
    }
  }

  async function deleteRecord(id) {
    try {
      const response = await fetch(`${API}/${id}`, {
        method: "DELETE"
      });

      if (!response.ok) {
        throw new Error("Could not delete record.");
      }

      setRecords((oldRecords) =>
        oldRecords.filter((record) => record.id !== id)
      );

      setError("");
    } catch {
      setError("Record could not be deleted.");
    }
  }

  return (
    <section className="usage-section">
      <h2>Water Usage Records</h2>
      <p>Add and manage your water consumption.</p>

      {error && <p className="error">{error}</p>}

      <form className="usage-form" onSubmit={addRecord}>
        <label>Date</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />

        <label>Category</label>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="Home">Home</option>
          <option value="Garden">Garden</option>
          <option value="Cleaning">Cleaning</option>
          <option value="Other">Other</option>
        </select>

        <label>Water Used (litres)</label>
        <input
          type="number"
          min="0.1"
          step="any"
          placeholder="Enter litres"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />

        <button type="submit">Add Record</button>
      </form>

      <h3>Usage History</h3>

      {records.length === 0 ? (
        <p>No records added yet.</p>
      ) : (
        <div className="usage-table">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Category</th>
                <th>Litres</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {records.map((record) => (
                <tr key={record.id}>
                  <td>{record.date}</td>
                  <td>{record.category}</td>
                  <td>{record.amount}</td>
                  <td>
                    <button
                      type="button"
                      onClick={() => deleteRecord(record.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export default UsageRecords;
