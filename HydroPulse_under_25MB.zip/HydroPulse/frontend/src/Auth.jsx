import { useState } from "react";

const API = "http://localhost:5000";

export default function Auth({ onLogin }) {
  const [isRegister, setIsRegister] = useState(false);
  const [userid, setUserid] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setMessage("");
    setLoading(true);

    try {
      const response = await fetch(
        `${API}/api/${isRegister ? "register" : "login"}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(
            isRegister
              ? { userid, name, password }
              : { userid, password }
          ),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Something went wrong.");
        return;
      }

      if (isRegister) {
        setMessage("Registration successful! Please log in.");
        setIsRegister(false);
        setPassword("");
      } else {
        onLogin(data);
      }
    } catch {
      setMessage("Cannot connect to backend. Check the server.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.page}>
      <form onSubmit={handleSubmit} style={styles.card}>
        <h1 style={styles.title}>HydroPulse</h1>
        <p style={styles.subtitle}>Water Monitoring System</p>

        <h2 style={styles.heading}>
          {isRegister ? "Create Account" : "Welcome Back"}
        </h2>

        <label style={styles.label}>User ID</label>
        <input
          style={styles.input}
          type="text"
          value={userid}
          onChange={(e) => setUserid(e.target.value)}
          placeholder="Enter user ID"
          autoComplete="username"
          required
        />

        {isRegister && (
          <>
            <label style={styles.label}>Full Name</label>
            <input
              style={styles.input}
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              autoComplete="name"
              required
            />
          </>
        )}

        <label style={styles.label}>Password</label>
        <input
          style={styles.input}
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder={
            isRegister ? "At least 8 characters" : "Enter password"
          }
          autoComplete={
            isRegister ? "new-password" : "current-password"
          }
          minLength={isRegister ? 8 : undefined}
          required
        />

        <button
          type="submit"
          style={styles.button}
          disabled={loading}
        >
          {loading
            ? "Please wait..."
            : isRegister
              ? "Register"
              : "Login"}
        </button>

        {message && (
          <p role="status" style={styles.message}>
            {message}
          </p>
        )}

        <p style={styles.switch}>
          {isRegister
            ? "Already have an account?"
            : "New to HydroPulse?"}{" "}
          <button
            type="button"
            style={styles.link}
            onClick={() => {
              setIsRegister(!isRegister);
              setMessage("");
              setPassword("");
            }}
          >
            {isRegister ? "Login" : "Register"}
          </button>
        </p>
      </form>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background: "#071321",
    color: "#e5f3ff",
    fontFamily: "Arial, sans-serif",
    padding: "20px",
    boxSizing: "border-box",
  },

  card: {
    width: "100%",
    maxWidth: "400px",
    padding: "30px",
    background: "#102338",
    border: "1px solid #29445d",
    borderRadius: "16px",
    boxSizing: "border-box",
  },

  title: {
    textAlign: "center",
    color: "#38bdf8",
    marginBottom: "5px",
  },

  subtitle: {
    textAlign: "center",
    color: "#9db4c8",
    marginBottom: "28px",
  },

  heading: {
    textAlign: "center",
    marginBottom: "20px",
  },

  label: {
    display: "block",
    marginTop: "16px",
    marginBottom: "7px",
  },

  input: {
    width: "100%",
    padding: "12px",
    borderRadius: "7px",
    border: "1px solid #38516a",
    background: "#071321",
    color: "white",
    boxSizing: "border-box",
  },

  button: {
    width: "100%",
    padding: "12px",
    marginTop: "22px",
    border: "none",
    borderRadius: "7px",
    background: "#0284c7",
    color: "white",
    fontWeight: "bold",
    cursor: "pointer",
  },

  message: {
    textAlign: "center",
    overflowWrap: "anywhere",
    color: "#7dd3fc",
    marginTop: "16px",
  },

  switch: {
    textAlign: "center",
    marginTop: "22px",
    color: "#bdccda",
  },

  link: {
    background: "none",
    border: "none",
    color: "#38bdf8",
    cursor: "pointer",
    fontWeight: "bold",
  },
};