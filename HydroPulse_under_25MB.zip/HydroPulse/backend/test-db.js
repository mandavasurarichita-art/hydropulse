
const pool = require("./db");

async function testDatabase() {
  try {
    const result = await pool.query("SELECT NOW()");
    console.log("PostgreSQL connected successfully!");
    console.log(result.rows[0]);
  } catch (error) {
    console.log("Database connection failed!");
    console.log(error.message);
  } finally {
    await pool.end();
  }
}

testDatabase();
