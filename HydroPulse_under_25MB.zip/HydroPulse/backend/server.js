
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const pool = require("./db");

const app = express();
const PORT = 5000;

const JWT_SECRET =
  process.env.JWT_SECRET || "local-dev-secret-change-before-deployment";

app.use(cors());
app.use(express.json());

// Home route
app.get("/", (req, res) => {
  res.send("HydroPulse backend is running!");
});

// REGISTER
app.post("/api/register", async (req, res) => {
  try {
    const { userid, name, password } = req.body;

    if (!userid || !name || !password) {
      return res.status(400).json({
        error: "User ID, name and password are required"
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        error: "Password must be at least 8 characters"
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO users (userid, name, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, userid, name, created_at`,
      [userid, name, passwordHash]
    );

    res.status(201).json({
      message: "Registration successful",
      user: result.rows[0]
    });
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({
        error: "User ID already exists"
      });
    }

    console.error("Registration error:", error.message);
    res.status(500).json({ error: "Registration failed" });
  }
});

// LOGIN
app.post("/api/login", async (req, res) => {
  try {
    const { userid, password } = req.body;

    if (!userid || !password) {
      return res.status(400).json({
        error: "User ID and password are required"
      });
    }

    const result = await pool.query(
      "SELECT * FROM users WHERE userid = $1",
      [userid]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        error: "Invalid user ID or password"
      });
    }

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(
      password,
      user.password_hash
    );

    if (!validPassword) {
      return res.status(401).json({
        error: "Invalid user ID or password"
      });
    }

    const token = jwt.sign(
      { id: user.id, userid: user.userid },
      JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        userid: user.userid,
        name: user.name
      }
    });
  } catch (error) {
    console.error("Login error:", error.message);
    res.status(500).json({ error: "Login failed" });
  }
});

// GENERATE AND SAVE ONE SENSOR READING
async function saveSensorReading() {
  try {
    // Simulated sensor values
    const waterLevel = Number((30 + Math.random() * 60).toFixed(2));
    const flowRate = Number((2 + Math.random() * 8).toFixed(2));
    const temperature = Number((20 + Math.random() * 15).toFixed(2));
    const waterQuality = Number((60 + Math.random() * 40).toFixed(2));

    // PostgreSQL records the current timestamp
    const result = await pool.query(
      `INSERT INTO telemetry
       (water_level, flow_rate, temperature, water_quality,
        recorded_at)
       VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
       RETURNING *`,
      [waterLevel, flowRate, temperature, waterQuality]
    );

    const row = result.rows[0];

    console.log("Sensor reading saved:", {
      id: row.id,
      waterLevel: row.water_level,
      flowRate: row.flow_rate,
      temperature: row.temperature,
      waterQuality: row.water_quality,
      recordedAt: row.recorded_at
    });
  } catch (error) {
    console.error("Sensor save failed:", error.message);
  }
}

// Start continuous sensor saving every 5 seconds
saveSensorReading();
setInterval(saveSensorReading, 5000);

// GET CURRENT SENSOR READING
app.get("/api/sensors", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM telemetry
       ORDER BY id DESC
       LIMIT 1`
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "No sensor readings available yet"
      });
    }

    const row = result.rows[0];

    res.json({
      id: row.id,
      waterLevel: Number(row.water_level),
      flowRate: Number(row.flow_rate),
      temperature: Number(row.temperature),
      waterQuality: Number(row.water_quality),
      recordedAt: row.recorded_at
    });
  } catch (error) {
    console.error("Current sensor error:", error.message);
    res.status(500).json({ error: "Could not get sensor reading" });
  }
});

// GET LAST 12 SENSOR READINGS
app.get("/api/sensors/history", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM (
         SELECT id, water_level, flow_rate, temperature,
                water_quality, recorded_at
         FROM telemetry
         ORDER BY id DESC
         LIMIT 12
       ) recent
       ORDER BY id ASC`
    );

    res.json(
      result.rows.map(row => ({
        id: row.id,
        waterLevel: Number(row.water_level),
        flowRate: Number(row.flow_rate),
        temperature: Number(row.temperature),
        waterQuality: Number(row.water_quality),
        recordedAt: row.recorded_at
      }))
    );
  } catch (error) {
    console.error("Sensor history error:", error.message);
    res.status(500).json({ error: "Could not get sensor history" });
  }
});

// USAGE RECORDS (in memory)
let usageRecords = [];
let nextUsageId = 1;

app.get("/api/usage", (req, res) => {
  res.json(usageRecords);
});

app.post("/api/usage", (req, res) => {
  const record = {
    id: nextUsageId++,
    ...req.body,
    createdAt: new Date()
  };

  usageRecords.push(record);
  res.status(201).json(record);
});

app.delete("/api/usage/:id", (req, res) => {
  const id = Number(req.params.id);
  usageRecords = usageRecords.filter(item => item.id !== id);
  res.json({ message: "Usage record deleted" });
});

// MAINTENANCE RECORDS (in memory)
let maintenanceRecords = [];
let nextMaintenanceId = 1;

app.get("/api/maintenance", (req, res) => {
  res.json(maintenanceRecords);
});

app.post("/api/maintenance", (req, res) => {
  const record = {
    id: nextMaintenanceId++,
    ...req.body,
    createdAt: new Date()
  };

  maintenanceRecords.push(record);
  res.status(201).json(record);
});

app.put("/api/maintenance/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = maintenanceRecords.findIndex(item => item.id === id);

  if (index === -1) {
    return res.status(404).json({
      error: "Maintenance record not found"
    });
  }

  maintenanceRecords[index] = {
    ...maintenanceRecords[index],
    ...req.body,
    id
  };

  res.json(maintenanceRecords[index]);
});

app.delete("/api/maintenance/:id", (req, res) => {
  const id = Number(req.params.id);
  maintenanceRecords = maintenanceRecords.filter(
    item => item.id !== id
  );

  res.json({ message: "Maintenance record deleted" });
});

// START SERVER
app.listen(PORT, () => {
  console.log(`HydroPulse backend running on port ${PORT}`);
  console.log("Sensor readings will be saved every 5 seconds.");
});
